/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package idadeemdias;

import java.io.DataInputStream;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author m.intra
 */
public class IdadeEmDias {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        DataInputStream dataInput = new DataInputStream(System.in);
        
        try {
            // Lê anos
            JOptionPane.showMessageDialog(null, "Informe sua idade em anos: ");
            int anos = Integer.parseInt(dataInput.readLine());

            // Lê meses
            JOptionPane.showMessageDialog(null, "Informe os meses adicionais: ");
            int meses = Integer.parseInt(dataInput.readLine());

            // Lê dias
            JOptionPane.showMessageDialog(null, "Informe os dias adicionais: ");
            int dias = Integer.parseInt(dataInput.readLine());

            // Calcula a idade em dias
            int idadeEmDias = (anos * 365) + (meses * 30) + dias;

            // Mostra a idade em dias
            JOptionPane.showMessageDialog(null, "Sua idade expressa em dias é: " + idadeEmDias);

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Erro ao ler dados: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Formato de número inválido: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
}




