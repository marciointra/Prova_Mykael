/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadora;

import javax.swing.JOptionPane;

/**
 *
 * @author m.intra
 */
public class Calculadora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int soma = 0;
        int quantidade = 0;
        double media = 0.0;
        String continuar;

        do {
            String numeroStr = JOptionPane.showInputDialog("Digite um número:");
            int numero = Integer.parseInt(numeroStr);

            soma += numero;
            quantidade++;

            continuar = JOptionPane.showInputDialog("Deseja continuar? (sim/não)");
        } while (continuar.equalsIgnoreCase("sim"));

        if (quantidade > 0) {
            media = (double) soma / quantidade;
        }

        JOptionPane.showMessageDialog(null, "Soma: " + soma);
        JOptionPane.showMessageDialog(null, "Quantidade: " + quantidade);
        JOptionPane.showMessageDialog(null, "Média: " + media);
    }
    
}
