/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package login;

import javax.swing.JOptionPane;

/**
 *
 * @author m.intra
 */
public class Login {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int codigoCorreto = 1234;

        int senhaCorreta = 9999;

        String codigoUsuarioStr = JOptionPane.showInputDialog("Digite o código de usuário:");
        int codigoUsuario = Integer.parseInt(codigoUsuarioStr);

        if (codigoUsuario != codigoCorreto) {
            JOptionPane.showMessageDialog(null, "Usuário inválido!");
        } else {
            String senhaStr = JOptionPane.showInputDialog("Digite a senha:");
            int senha = Integer.parseInt(senhaStr);

            if (senha != senhaCorreta) {
                JOptionPane.showMessageDialog(null, "Senha incorreta!");
            } else {
                JOptionPane.showMessageDialog(null, "Acesso permitido");
            }
        }
    } 
}
