/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tabuada;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

/**
 *
 * @author m.intra
 */
public class Tabuada {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String numeroStr = JOptionPane.showInputDialog("Digite um número inteiro:");
        int numero = Integer.parseInt(numeroStr);

        String caminhoArquivo = System.getProperty("user.home") + "/Desktop/tabuada_" + numero + ".txt";

        try (FileWriter fileWriter = new FileWriter(caminhoArquivo);
             PrintWriter printWriter = new PrintWriter(fileWriter)) {

            for (int i = 1; i <= 10; i++) {
                printWriter.println(numero + " x " + i + " = " + (numero * i));
            }

            JOptionPane.showMessageDialog(null, "Tabuada do " + numero + " foi salva em: " + caminhoArquivo);

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Ocorreu um erro ao salvar o arquivo: " + e.getMessage());
        }
    }
}
