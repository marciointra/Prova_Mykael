/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package qualeofilme;

import javax.swing.JOptionPane;

/**
 *
 * @author m.intra
 */
public class QualEoFilme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String nomeJogador1 = JOptionPane.showInputDialog("Jogador 1 - Digite seu nome:");
        String nomeFilme = JOptionPane.showInputDialog(nomeJogador1 + " - Digite o nome do filme:");

        String[] pistas = new String[5];
        for (int i = 0; i < 5; i++) {
            pistas[i] = JOptionPane.showInputDialog(nomeJogador1 + " - Digite a pista " + (i + 1) + ":");
        }

        String nomeJogador2 = JOptionPane.showInputDialog("Jogador 2 - Digite seu nome:");

        boolean acertou = false;
        for (int i = 0; i < 5; i++) {
            String tentativa = JOptionPane.showInputDialog(nomeJogador2 + ", a pista " + (i + 1) + " é: " + pistas[i] + "\n" + nomeJogador2 + ", Qual o nome do filme?");
            if (tentativa.equalsIgnoreCase(nomeFilme)) {
                JOptionPane.showMessageDialog(null, nomeJogador2 + ", você acertou! O nome do filme é " + nomeFilme + ".");
                acertou = true;
                break;
            } else {
                JOptionPane.showMessageDialog(null, nomeJogador2 + ", você errou!");
            }
        }

        if (!acertou) {
            JOptionPane.showMessageDialog(null, nomeJogador2 + ", suas chances acabaram! O nome do filme era " + nomeFilme + ".");
        }
    }
    
}
