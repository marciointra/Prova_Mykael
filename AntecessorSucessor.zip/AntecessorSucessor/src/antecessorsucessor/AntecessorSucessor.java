/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package antecessorsucessor;

import javax.swing.JOptionPane;

/**
 *
 * @author m.intra
 */
public class AntecessorSucessor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            String input = JOptionPane.showInputDialog("Digite um número inteiro:");
            int numero = Integer.parseInt(input);

            int antecessor = numero - 1;
            int sucessor = numero + 1;

            String mensagem = "Número digitado: " + numero + "\nAntecessor: " + antecessor + "\nSucessor: " + sucessor;
            JOptionPane.showMessageDialog(null, mensagem, "Resultado", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, digite um número inteiro válido.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}
