/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lutador;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import javax.swing.JOptionPane;

/**
 *
 * @author m.intra
 */
public class Lutador {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String nomeLutador = JOptionPane.showInputDialog("Digite seu nome so lutador:");
        String pesoLutador = JOptionPane.showInputDialog(nomeLutador + " - Digite o peso:");
        int peso = Integer.parseInt(pesoLutador);

        if (peso <= 65) {
             JOptionPane.showMessageDialog(null, " O lutador "+nomeLutador + ",  pesa " + peso + " e se enquadra na categoria: PENA " );
             String caminhoArquivo = System.getProperty("user.home") + "/Desktop/Categoria_lutador_" + nomeLutador + ".txt";
         try (FileWriter fileWriter = new FileWriter(caminhoArquivo);
                    PrintWriter printWriter = new PrintWriter(fileWriter)) {
                    printWriter.println(" O lutador "+nomeLutador + ",  pesa " + peso + " e se enquadra na categoria: PESADO ");
            } catch (IOException e) {
                    JOptionPane.showMessageDialog(null, "Ocorreu um erro ao salvar o arquivo: " + e.getMessage());
            }
        }
         else if (peso > 65 && peso <= 72 ) {
             JOptionPane.showMessageDialog(null, " O lutador "+nomeLutador + ",  pesa " + peso + " e se enquadra na categoria: LEVE " );
             String caminhoArquivo = System.getProperty("user.home") + "/Desktop/Categoria_lutador_" + nomeLutador + ".txt";
         try (FileWriter fileWriter = new FileWriter(caminhoArquivo);
                    PrintWriter printWriter = new PrintWriter(fileWriter)) {
                    printWriter.println(" O lutador "+nomeLutador + ",  pesa " + peso + " e se enquadra na categoria: PESADO ");
            } catch (IOException e) {
                    JOptionPane.showMessageDialog(null, "Ocorreu um erro ao salvar o arquivo: " + e.getMessage());
            }
        }
         else if (peso > 72 && peso <= 79 ) {
             JOptionPane.showMessageDialog(null, " O lutador "+nomeLutador + ",  pesa " + peso + " e se enquadra na categoria: LIGEIRO " );
             String caminhoArquivo = System.getProperty("user.home") + "/Desktop/Categoria_lutador_" + nomeLutador + ".txt";
         try (FileWriter fileWriter = new FileWriter(caminhoArquivo);
                    PrintWriter printWriter = new PrintWriter(fileWriter)) {
                    printWriter.println(" O lutador "+nomeLutador + ",  pesa " + peso + " e se enquadra na categoria: PESADO ");
            } catch (IOException e) {
                    JOptionPane.showMessageDialog(null, "Ocorreu um erro ao salvar o arquivo: " + e.getMessage());
            }
        }
         else if (peso > 79 && peso <= 86 ) {
             JOptionPane.showMessageDialog(null, " O lutador "+nomeLutador + ",  pesa " + peso + " e se enquadra na categoria: MEIO MEDIO " );
             String caminhoArquivo = System.getProperty("user.home") + "/Desktop/Categoria_lutador_" + nomeLutador + ".txt";
         try (FileWriter fileWriter = new FileWriter(caminhoArquivo);
                    PrintWriter printWriter = new PrintWriter(fileWriter)) {
                    printWriter.println(" O lutador "+nomeLutador + ",  pesa " + peso + " e se enquadra na categoria: PESADO ");
            } catch (IOException e) {
                    JOptionPane.showMessageDialog(null, "Ocorreu um erro ao salvar o arquivo: " + e.getMessage());
            }
        }
         else if (peso > 86 && peso <= 93 ) {
             JOptionPane.showMessageDialog(null, " O lutador "+nomeLutador + ",  pesa " + peso + " e se enquadra na categoria: MEDIO " );
             String caminhoArquivo = System.getProperty("user.home") + "/Desktop/Categoria_lutador_" + nomeLutador + ".txt";
         try (FileWriter fileWriter = new FileWriter(caminhoArquivo);
                    PrintWriter printWriter = new PrintWriter(fileWriter)) {
                    printWriter.println(" O lutador "+nomeLutador + ",  pesa " + peso + " e se enquadra na categoria: PESADO ");
            } catch (IOException e) {
                    JOptionPane.showMessageDialog(null, "Ocorreu um erro ao salvar o arquivo: " + e.getMessage());
            }
        }
         else if (peso > 93 && peso <= 100 ) {
             JOptionPane.showMessageDialog(null, " O lutador "+nomeLutador + ",  pesa " + peso + " e se enquadra na categoria: MEIO PESADO " );
             String caminhoArquivo = System.getProperty("user.home") + "/Desktop/Categoria_lutador_" + nomeLutador + ".txt";
             try (FileWriter fileWriter = new FileWriter(caminhoArquivo);
                    PrintWriter printWriter = new PrintWriter(fileWriter)) {
                    printWriter.println(" O lutador "+nomeLutador + ",  pesa " + peso + " e se enquadra na categoria: PESADO ");
            } catch (IOException e) {
                    JOptionPane.showMessageDialog(null, "Ocorreu um erro ao salvar o arquivo: " + e.getMessage());
            }
        }
         else  {
             JOptionPane.showMessageDialog(null, " O lutador "+nomeLutador + ",  pesa " + peso + " e se enquadra na categoria: PESADO " );
             String caminhoArquivo = System.getProperty("user.home") + "/Desktop/Categoria_lutador_" + nomeLutador + ".txt";
             try (FileWriter fileWriter = new FileWriter(caminhoArquivo);
                    PrintWriter printWriter = new PrintWriter(fileWriter)) {
                    printWriter.println(" O lutador "+nomeLutador + ",  pesa " + peso + " e se enquadra na categoria: PESADO ");
            } catch (IOException e) {
                    JOptionPane.showMessageDialog(null, "Ocorreu um erro ao salvar o arquivo: " + e.getMessage());
            }
        }
     }
}
