/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package maquinadecafe;

import java.io.DataInputStream;
import javax.swing.JOptionPane;

/**
 *
 * @author m.intra
 */
public class MaquinaDeCafe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       DataInputStream dataInput = new DataInputStream(System.in);

        int quantidadeExpresso = 0;
        int quantidadeCapuccino = 0;
        int quantidadeLeiteComCafe = 0;

        double valorExpresso = 0.75;
        double valorCapuccino = 1.00;
        double valorLeiteComCafe = 1.25;

        double totalExpresso = 0;
        double totalCapuccino = 0;
        double totalLeiteComCafe = 0;
        double totalVendas = 0;

        while (true) {
            try {
                String menu = "Selecione uma opção:\n"
                            + "1 - Café Expresso\n"
                            + "2 - Café Capuccino\n"
                            + "3 - Leite com Café\n"
                            + "4 - Totalizar Vendas\n";

                int opcao = Integer.parseInt(JOptionPane.showInputDialog(menu));

                if (opcao == 1) {
                    quantidadeExpresso++;
                    totalExpresso += valorExpresso;
                } else if (opcao == 2) {
                    quantidadeCapuccino++;
                    totalCapuccino += valorCapuccino;
                } else if (opcao == 3) {
                    quantidadeLeiteComCafe++;
                    totalLeiteComCafe += valorLeiteComCafe;
                } else if (opcao == 4) {
                    totalVendas = totalExpresso + totalCapuccino + totalLeiteComCafe;
                    String relatorio = "Relatório de Vendas:\n"
                                     + "Café Expresso: " + quantidadeExpresso + " vendidos, Valor Total: R$ " + totalExpresso + "\n"
                                     + "Café Capuccino: " + quantidadeCapuccino + " vendidos, Valor Total: R$ " + totalCapuccino + "\n"
                                     + "Leite com Café: " + quantidadeLeiteComCafe + " vendidos, Valor Total: R$ " + totalLeiteComCafe + "\n"
                                     + "Total de todos os cafés vendidos: Valor Total: R$ " + totalVendas;
                    JOptionPane.showMessageDialog(null, relatorio, "Totalização de Vendas", JOptionPane.INFORMATION_MESSAGE);
                    break; // Finaliza a leitura
                } else {
                    JOptionPane.showMessageDialog(null, "Opção inválida! Tente novamente.", "Erro", JOptionPane.ERROR_MESSAGE);
                }

            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Entrada inválida! Por favor, insira um número válido.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
